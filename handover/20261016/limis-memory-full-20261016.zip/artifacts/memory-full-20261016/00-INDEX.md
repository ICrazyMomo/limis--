# 全量记忆分文件索引
导出：2026-10-16 20:11:13 CST
主文件：/workspace/artifacts/团队与Jarvis全量聊天记忆-至20261016.md

| 文件 | 成员 | 条数 |
|---|---|---:|
| `Jarvis.md` | Jarvis | 6161 |
| `limis-研发.md` | limis-研发 | 3336 |
| `limis-研发2.md` | limis-研发2 | 1205 |
| `limis-研发3.md` | limis-研发3 | 968 |
| `limis-研发4.md` | limis-研发4 | 661 |
| `limis-研发5.md` | limis-研发5 | 174 |
| `limis-测试.md` | limis-测试 | 6213 |
| `limis-测试2.md` | limis-测试2 | 1554 |
| `limis-测试3.md` | limis-测试3 | 1588 |
| `limis-测试4.md` | limis-测试4 | 1342 |
| `limis-测试5.md` | limis-测试5 | 1207 |
| `limis-产品.md` | limis-产品 | 5906 |
| `limis-设计.md` | limis-设计 | 171 |
| `limis-业务分析.md` | limis-业务分析 | 1973 |
| `limis-运维.md` | limis-运维 | 5442 |
| `limis-观察者.md` | limis-观察者 | 15 |
| `limis-云端出包优化.md` | limis-云端出包优化 | 94 |
| `Claude程序员-llm.md` | Claude程序员-llm | 3 |
| `Claude程序员-mod.md` | Claude程序员-mod | 1 |
| `DeepSeek.md` | DeepSeek | 1 |
| `ZCode.md` | ZCode | 2 |
| `00-Jarvis-voice-calls.md` | Jarvis 语音 | 500 turns |
