# SHA 自检 · 防漂移 · tip `adf04e44`

时刻：2026-10-17 07:49:07 +0800 Asia/Shanghai

| 产物 | sha16 | 全 sha256 |
|---|---|---|
| NEW class | `30bbb73e75c12fb5` | `30bbb73e75c12fb5853608bb20633a504f919bd30ad560f0cd50aa7397f2e470` |
| NEW xml | `958de353f30e6cae` | `958de353f30e6cae1adfc87f0b88ec4edc4b86697172bf14b7d434eb15c89cf1` |
| ORIG class | `f87b79c3ced64448` | `f87b79c3ced6444800f3e834dd872507b1bbc866105a5b2f41ee8fc55d950c4b` |
| ORIG xml | `a305b1d371af6551` | `a305b1d371af6551e252d1e541ab71c12b2fe1b0c79457c970817298f81fdfb6` |
| tip tgz | `3d40b9c9261bcf4e` | `3d40b9c9261bcf4e2547d6ba80623f795820a5d7e0f9ae4802b8976c425dadc2` |

OUTER≡NESTED：class 四处同 `30bbb73e75c12fb5`；xml 四处同 `958de353f30e6cae`。

**口径**：tgz 在交件目录定稿**后**再算包外 sha；本表与 `SHA16-TGZ.txt` / `stamps/TGZ.sha16` 一致。
